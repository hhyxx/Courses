export const MODULE_A = 'MODULE_A';
export const MODULE_B = 'MODULE_B';
